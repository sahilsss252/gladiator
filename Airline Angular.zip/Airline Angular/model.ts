// // To parse this data:
// //
// //   import { Convert } from "./file";
// //
// //   const flighDetails = Convert.toFlighDetails(json);

// export interface FlighDetails {
//     flightId:              number;
//     source:                Source;
//     destination:           Destination;
//     carrier:               Carrier;
//     flightSchedule:        null;
//     flightScheduleDetails: FlightScheduleDetail[];
// }

// export enum Carrier {
//     Kingfisher = "kingfisher",
// }

// export enum Destination {
//     Mumbai = "mumbai",
// }

// export interface FlightScheduleDetail {
//     scheduleId:    number;
//     departureDate: Date;
//     arrival:       number[];
//     departure:     number[];
//     economySeats:  number;
//     economyPrice:  number;
//     businessSeats: number;
//     businessPrice: number;
//     duration:      number;
//     ecomonySeats:  number;
// }

// export enum Source {
//     Pune = "pune",
// }

// // Converts JSON strings to/from your types
// export class Convert {
//     public  toFlighDetails(json: string): FlighDetails[] {
//         return JSON.parse(json);
//     }

//     public  flighDetailsToJson(value: FlighDetails[]): string {
//         return JSON.stringify(value);
//     }
// }
