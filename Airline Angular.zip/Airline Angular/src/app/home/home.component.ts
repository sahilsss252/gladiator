import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceOneService } from '../service-one.service';
import { SearchFlight } from '../searchFlight';
import { stringify } from 'querystring';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  searchFlight : SearchFlight = new SearchFlight();

  source = false;
  destination = false;
  departuredate =false;
  searchFlightDetail;
  viewDetails;
  s1:string="Economy";
  s2:string="Business";
  classType1:string;
  classType2:string;
  checkClassType:string;
  

  searchFlightDetailAfterLogin;
  
  constructor(private router : Router,private service :ServiceOneService) { }
  count=0;
 
  ngOnInit(): void {
   

  }
  
    created =sessionStorage.getItem("logged");
    availableSeats=sessionStorage.getItem("seats");
 

  price=sessionStorage.getItem("price");
  searchFlightDetails(source: string,destination:string,departuredate:Date) {
    this.service.searchFlight(source,destination,departuredate);
    console.log(this.searchFlight);
     this.service.searchFlight(source,destination,departuredate).subscribe((data)=>{
       console.log(data);

       if(data!=0){
        console.log(data)

        this.searchFlightDetail=data;
      
      }
      
      else{
        alert("Flight Not available")
      }


       

     })
   }


   searchFlightDetailsAfterLogin(source:string,destination:string,departuredate:Date,classType:string){
      console.log(source,destination,departuredate,classType);

      

      sessionStorage.setItem("ct",classType);
  
      if(sessionStorage.getItem("ct")==this.s1){
      this.classType1=sessionStorage.getItem("ct");
      this.classType2=null;
     
      }
      if(sessionStorage.getItem("ct")==this.s2 ){
        this.classType2=sessionStorage.getItem("ct");
        console.log(this.classType2);
        this.classType1=null;
    

      }




      this.service.searchFlightAfterLogin(source,destination,departuredate,classType);
      this.service.searchFlightAfterLogin(source,destination,departuredate,classType).subscribe((data)=>{
        console.log(data);
        // console.log(data[0][0]);
        
        this.checkClassType=classType;
       
        this.searchFlightDetailAfterLogin=data;
        console.log(this.searchFlightDetailsAfterLogin)
     })
  }

   bookTicket() {

   
    if(this.created!='0'){
      this.router.navigate(['login']);
    }
    
    
    

   }

   bookTicketAfterLogin(scheduleId,seatNo){
      this.count;
      this.router.navigate(['addPassenger']);
      sessionStorage.setItem("scheduleId",scheduleId);
      console.log(seatNo);
      console.log(sessionStorage.getItem("scheduleId"));

      //availble seats
      sessionStorage.setItem("seats",seatNo);
      
      console.log(this.checkClassType);
      if(this.checkClassType=="Economy"){
        sessionStorage.setItem("flightClass",this.classType1)
        let sub=this.s1.concat(seatNo);
        sessionStorage.setItem("seatNo",sub)
        console.log(sub)
      }
      else{
        let sub=this.s2.concat(seatNo);
        sessionStorage.setItem("seatNo",sub)
        sessionStorage.setItem("flightClass",this.classType2)
        console.log(sub)
      }

   }
}
