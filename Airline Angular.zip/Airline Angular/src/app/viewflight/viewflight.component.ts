import { Component, OnInit } from '@angular/core';
import { ServiceOneService } from '../service-one.service';
import { Router } from '@angular/router';
import { ViewFlightDetails } from '../viewFlightDetails';
import { FlightSchedule } from '../flightSchedule';

@Component({
  selector: 'app-viewflight',
  templateUrl: './viewflight.component.html',
  styleUrls: ['./viewflight.component.css']
})
export class ViewflightComponent implements OnInit {
  
  viewFlightDetails:ViewFlightDetails=new ViewFlightDetails();
  viewDetails;
 
  constructor(private service : ServiceOneService, private router : Router) { }

  ngOnInit(): void {
    this.service.getFlight().subscribe((data)=>{
      console.log(data);
      this.viewDetails=data;
      //this.model.toFlighDetails(JSON.stringify(data));
      
    
    })
   
  }
  submit()
  {
    this.router.navigate(['adminPage']);
  }


}
