import { Time } from '@angular/common';
import { FlightSchedule } from './flightSchedule';

export class ViewFlightDetails {
    scheduleId : number;
    source: string;
    destination:string;
    carrier : string;
    flightSchedule:FlightSchedule;
    
    
}