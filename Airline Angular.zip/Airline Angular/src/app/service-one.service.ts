
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { User } from './User';
import { UserLogin } from './Userlogin';
import { Admin } from './admin';
import { DeleteFlight } from './deleteFlight';
import { SearchFlight } from './searchFlight';
import { FlightDetails } from './FlightDetails';
import { Passenger, AddPassenger } from './addPassenger';
@Injectable({
    providedIn: 'root'
})
 export class ServiceOneService{
   loggedUser ;
    addPassenger : AddPassenger =new AddPassenger;
  
     constructor(private http:HttpClient) {}

     addUser(user: User){
         let url="http://192.168.14.72:8282/Airline/register";
         this.http.post(url,user).subscribe((data)=>{
             console.log(data);
         })
     }

   
     loginUser(login: UserLogin){
        //  console.log(login);
        let url="http://192.168.14.72:8282/Airline/login";
        //return this.http.get(url);
        return this.http.post(url,login)
        
    }

    
    loginAdmin(admin: Admin){
        let url="http://192.168.14.72:8282/Airline/adminlogin";
        return this.http.post(url,admin)
        //.subscribe((data)=>{
        //     console.log(data);
        // })
    }

    addFlight(addFlight: FlightDetails){
        let url="http://192.168.14.72:8282/Airline/addFlight";
        this.http.post(url,addFlight).subscribe((data)=>{
            console.log(data);
            
        })
    }

    deleteFlight(deleteFlight: DeleteFlight){
        console.log(deleteFlight);
        let url="http://192.168.14.68:8989/Airline/addPassenger";
        this.http.post(url,deleteFlight).subscribe((data)=>{
            console.log(data);
        })
    }
    
    getFlight(){
        let urlViewFlight="http://192.168.14.72:8282/Airline/viewFlight";
        return this.http.get(urlViewFlight);

    }

    searchFlight(source : string,destination: string,departuredate:Date){
        let urlGetFlight="http://192.168.14.72:8282/Airline/getFlight/"+ source +"/"+ destination+"/"+ departuredate;
        // + searchFlight.source +"/"+ searchFlight.destination+"/"+searchFlight.departuredate ;
         return this.http.get(urlGetFlight);
    }

    addPassengerDetails(passenger : Passenger){



        let url="http://192.168.14.72:8282/Airline/addPassenger";
        let userId = JSON.parse(sessionStorage.getItem("logged"));
        let scheduleId= JSON.parse(sessionStorage.getItem("scheduleId"));
        let availableSeats=JSON.parse(sessionStorage.getItem("seats"));
        let seatNo =sessionStorage.getItem("seatNo");
        let flightClass =sessionStorage.getItem("flightClass");
        
        this.addPassenger.passengername=passenger.name;
        this.addPassenger.passengerAge=passenger.age;
        this.addPassenger.passengerGender=passenger.gender;
        
        this.addPassenger.userId= userId;
        this.addPassenger.scheduleId=scheduleId;
        this.addPassenger.seatNo=seatNo;
        this.addPassenger.flightClass=flightClass;
        this.addPassenger.availableSeats= availableSeats;

        console.log(this.addPassenger);
        this.http.post(url,this.addPassenger).subscribe((data)=>{
            console.log(data);


            
        })
    }

    searchFlightAfterLogin(source : string,destination: string,departuredate:Date,classType :string){
        let urlGetFlight="http://192.168.14.72:8282/Airline/getFlightAfterLogin/"+ source +"/"+ destination+"/"+ departuredate +"/"+classType;
        // + searchFlight.source +"/"+ searchFlight.destination+"/"+searchFlight.departuredate ;
         return this.http.get(urlGetFlight);
    }


 }