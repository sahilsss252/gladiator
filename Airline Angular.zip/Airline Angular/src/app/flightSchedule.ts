import { Time } from '@angular/common';

export class FlightSchedule {
    scheduleStartDate :Date;
    durationInMonths : number;
    arrival:Time;
    departure:Time;
    economySeats:number;
    economyPrice:number;
    bussinessSeats:number;
    bussinessPrice:number;
}