export class Validate{
     
    PASS_REGEXP= /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{6,100})/;
    NAME_REGEXP="^[a-zA-Z\s]*$";
    CHAR_REGEX=/^[a-zA-Z]/;
  
    MAIL_REGEXP = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
    constructor() { }
    validateFirstName(fname){
        
      
      
      if(fname==null){
     
          return false;   
        }
        else       
      
        return true;
      }

      validatelastName(lname){
        if(lname==null){
     
          return false;   
        }
        else       
      
        return true;
      }

      validatetitleName(title){
        if(title==null){
     
          return false;   
        }
        else       
      
        return true;
      }


      validateMobilenumber(mobNo){
       
        if(mobNo!=10){return false;}
        else{return true;}
        }

      validateEmail(email){
        if( !this.MAIL_REGEXP.test(email) ){return false;
        alert("reached")}
        else {return true;}
      }

      

        validatePassword(password){
            if(this.PASS_REGEXP.test(password)){
              return true;}
            else{ return false; }
          }   
          
          

          
          validateDestination(destination){
            if(this.PASS_REGEXP.test(destination)){
              return true;}
            else{ return false; }
 
          }
          
          validateDepartureDate(departureDate){
            var pattern = /^([0-9]{2})-([0-9]{2})-([0-9]{4})$/;
            if (departureDate == null || departureDate == "" || !pattern.test(departureDate)) {
               
                return false;
            }
            else {
                return true;
              }
          } 

          validateDuration(duration){
            var pattern=/^(0?[1-9]|1[012]):[0-5][0-9]$/;
            if(duration == null || duration =="" || !pattern.test(duration))
            {
              return true;}
            else{ return false; }
          } 

          validateArrivalTime(arrivalTime){
            var pattern=/^(0?[1-9]|1[012]):[0-5][0-9]$/;
            if(arrivalTime == null || arrivalTime =="" || !pattern.test(arrivalTime))
            {
              return true;}
            else{ return false; }
          } 

          validateDepartureTime(departureTime){
            var pattern=/^(0?[1-9]|1[012]):[0-5][0-9]$/;
            if(departureTime == null || departureTime =="" || !pattern.test(departureTime))
            {
              return true;}
            else{ return false; }
          } 
          validateEconomySeats(economySeats){
            if(this.PASS_REGEXP.test(economySeats)){
              return true;}
            else{ return false; }
          } 

          validateEcomomyPrice(economyPrice){
            if(this.PASS_REGEXP.test(economyPrice)){
              return true;}
            else{ return false; }
          } 
          validateBussinessSeats(bussinessSeats){
            if(this.PASS_REGEXP.test(bussinessSeats)){
              return true;}
            else{ return false; }
          } 
          validateBussinessPrice(bussinessPrice){
            if(this.PASS_REGEXP.test(bussinessPrice)){
              return true;}
            else{ return false; }
          } 
         
}
