import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceOneService } from '../service-one.service';
import { Validate } from '../Validate';
import { Admin } from '../admin';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  username =false;
  password =false;

  admin : Admin =new Admin();
  
  constructor(private router : Router, private service: ServiceOneService) { }

  ngOnInit(): void {
  }  

  loginSubmit(){

      console.log(this.admin)
  
       this.service.loginAdmin(this.admin).subscribe((data)=>{
        
        
        if(data!=0){
          console.log(data)

          sessionStorage.setItem("logged",JSON.stringify(data[0].adminId));
          this.router.navigate(['adminPage']);
        
        }
        
        else{
          alert("invalid user")
        }

      });
      
}

    }
    
    
  


