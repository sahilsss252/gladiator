import { Component, OnInit } from '@angular/core';
import { DeleteFlight } from '../deleteFlight';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
import { ServiceOneService } from '../service-one.service';

@Component({
  selector: 'app-delete-flight',
  templateUrl: './delete-flight.component.html',
  styleUrls: ['./delete-flight.component.css']
})
export class DeleteFlightComponent implements OnInit {

  deleteFlight : DeleteFlight = new DeleteFlight();


  constructor(private router: Router, private http: HttpClient, private formBuilder: FormBuilder,private service :ServiceOneService) { }

  source = false;
  destination = false;
  departureDate = false;
  carrier = false;
  arrivalTime = false;
  departureTime = false;

  ngOnInit(): void {
  }

  deleteSubmit(){
    console.log((this.deleteFlight));
    
    this.service.deleteFlight(this.deleteFlight);
    this.router.navigate(['adminPage']);
  }

}
