import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AddFlightComponent } from './add-flight/add-flight.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AdminComponent } from './admin/admin.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { ViewflightComponent } from './viewflight/viewflight.component';
import { DeleteFlightComponent } from './delete-flight/delete-flight.component';
import { ContactComponent } from './contact/contact.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AddPassengerComponent } from './add-passenger/add-passenger.component';
import { ThankyouComponent } from './thankyou/thankyou.component';
import { BankdetailsComponent } from './bankdetails/bankdetails.component';


const routes: Routes = [
  {path:'', component:HomeComponent},
  {path:'home', component:HomeComponent},
  {path:'login' , component:LoginComponent},
  {path : 'register' , component : RegisterComponent},
  {path :'header', component:HeaderComponent},
  {path :'footer', component:FooterComponent},
  {path:'adminLogin', component:AdminComponent },
  {path:'contact', component:ContactComponent},
  {path:'aboutus', component:AboutusComponent},
  
  {path:'adminPage', component:AdminPageComponent},
  {path :'addFlight', component : AddFlightComponent},
  {path :'viewFlight', component : ViewflightComponent},
  {path :'deleteFlight' , component : DeleteFlightComponent},
  {path:'addPassenger', component:AddPassengerComponent},
  {path:'bankdetails', component:BankdetailsComponent},
  {path:'thankYou',component:ThankyouComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
