import { Time } from '@angular/common';

export class DeleteFlight{
  source: string;
  destination:string;
  carrier : string;
  departureDate:Date;
  arrivalTime:Time;
  departureTime:Time;
  
}