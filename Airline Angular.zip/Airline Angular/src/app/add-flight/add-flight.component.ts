import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { HttpClient } from '@angular/common/http';

import { ServiceOneService } from '../service-one.service';
import { FlightSchedule } from '../flightSchedule';
import { FlightDetails } from '../FlightDetails';





@Component({
  selector: 'app-add-flight',
  templateUrl: './add-flight.component.html',
  styleUrls: ['./add-flight.component.css']
})
export class AddFlightComponent implements OnInit {

  flightDetails: FlightDetails = new FlightDetails();
 

  constructor(private router: Router, private http: HttpClient, private formBuilder: FormBuilder,private service :ServiceOneService) { }


  

  ngOnInit() {

  }

  addSubmit() {
   
    console.log(this.flightDetails);
    this.service.addFlight(this.flightDetails);
    this.router.navigate(['adminPage']);
   
  }

}
