import { Time } from '@angular/common';

export class FlightDetails {
  source: string;
  destination:string;
  carrier : string;
  scheduledStartDate :Date;
  durationInMonths : number;
  arrival:Time;
  departure:Time;
  economySeats:number;
  economyPrice:number;
  businessSeats:number;
  businessPrice:number;

}