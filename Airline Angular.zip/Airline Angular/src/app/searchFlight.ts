


export class SearchFlight{
    source : string;
    destination :string;
    departuredate : Date;
    numberOfPasssenger : number;
    classType:string;
}