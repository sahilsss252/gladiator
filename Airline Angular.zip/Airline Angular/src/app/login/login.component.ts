import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Validate } from '../Validate';
import { ServiceOneService } from '../service-one.service';
import { UserLogin } from '../Userlogin';
import { invalid } from '@angular/compiler/src/render3/view/util';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email = false;
  password = false;
  userData;
  login:UserLogin = new UserLogin();
  
  constructor(private http: HttpClient, private router: Router, private service :ServiceOneService) { }
  
  ngOnInit():void {

  }
  loginSubmit() {
   
      this.service.loginUser(this.login).subscribe((data)=>{
        
        
        if(data!=0){
          console.log(data)

          sessionStorage.setItem("logged",JSON.stringify(data[0].userId));
          this.router.navigate(['home']);
        
        }
        
        else{
          alert("invalid user")
        }

      }); 
      
      
}


    
  }


