export class User
{
  title:string;

  firstName: string;
  lastName : string;
  mobileNo: number;
  email : string;
  password : string;
}