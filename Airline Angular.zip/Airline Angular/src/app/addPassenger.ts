export class Passenger {
    name : string;
    age: number;
    gender : string;
    //class : string;
    //seatNo: string;
    
    
}

export class AddPassenger {
    userId : number;
    scheduleId:number;
    passengername : string;
    passengerAge: number;
    passengerGender : string;
    
    seatNo:string;
    flightClass:string;
    availableSeats:number;

    
}