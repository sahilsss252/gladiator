import { Component, OnInit } from '@angular/core';
import { Passenger } from '../addPassenger';
import { ServiceOneService } from '../service-one.service';
import { UserLogin } from '../Userlogin';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-passenger',
  templateUrl: './add-passenger.component.html',
  styleUrls: ['./add-passenger.component.css']
})
export class AddPassengerComponent implements OnInit {

  constructor(private service : ServiceOneService,private router:Router) { }

  addPassenger = new Passenger()
  
  dataArray=[];

  ngOnInit(): void {

    this.addPassenger=new Passenger();
    this.dataArray.push(this.addPassenger)
    
  }

  addForm() {
    this.addPassenger=new Passenger();
    this.dataArray.push(this.addPassenger);
  }

  
  onSubmit() {
    this.service.addPassengerDetails(this.addPassenger);
    this.router.navigate(['bankdetails']);
  }

}
